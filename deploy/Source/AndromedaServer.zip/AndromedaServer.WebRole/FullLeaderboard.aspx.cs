﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using Andromeda.Data;
using Andromeda.ServerEntities;

namespace Andromeda.WebPages
{
    public partial class FullLeaderboard : System.Web.UI.Page
    {

    }
}