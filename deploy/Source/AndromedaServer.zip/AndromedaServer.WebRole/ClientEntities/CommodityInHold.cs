﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace Andromeda.ClientEntities
{
    public class CommodityInHold
    {
        public string Name { get; set; }
        public int Stock { get; set; }
    }
}