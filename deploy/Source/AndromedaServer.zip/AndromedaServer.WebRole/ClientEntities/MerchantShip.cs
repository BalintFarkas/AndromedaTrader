﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace Andromeda.ClientEntities
{
    public class MerchantShip
    {
        public Guid TransponderCode { get; set; }
        public double Distance { get; set; }
    }
}